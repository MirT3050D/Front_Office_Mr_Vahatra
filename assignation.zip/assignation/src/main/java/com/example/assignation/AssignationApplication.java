package com.example.assignation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignationApplication.class, args);
	}

}
