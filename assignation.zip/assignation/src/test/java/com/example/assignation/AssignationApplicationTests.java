package com.example.assignation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignationApplicationTests {

	@Test
	void contextLoads() {
	}

}
